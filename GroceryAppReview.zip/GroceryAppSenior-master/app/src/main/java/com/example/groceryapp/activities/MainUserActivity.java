package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.groceryapp.adapters.AdapterCallback;
import com.example.groceryapp.adapters.AdapterOrderUser;
import com.example.groceryapp.adapters.AdapterShoppingList;
import com.example.groceryapp.adapters.AdapterSupermarket;
import com.example.groceryapp.Constants;
import com.example.groceryapp.adapters.AdapterProduct;
import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelOrderUser;
import com.example.groceryapp.models.ModelSupermarket;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.models.ModelsmProduct;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainUserActivity extends AppCompatActivity {

    private TextView nameTv, emailTv, tabProductsTv, tabShoppingListTv, tabHistoryTv, tabSupermarketTv, filteredProductTv;
    private EditText searchProductEt;
    private ImageButton logoutBtn, filterProductBtn;
    private RelativeLayout productsRl, shoppingListRl, historyRl, supermarketRl;
    private RecyclerView productsRv, supermarketRv, shoppingListtRv, historyRv;

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    private ArrayList<ModelProduct> productList;
    private ArrayList<ModelSupermarket> supermarketList;
    private ArrayList<ModelProduct> cartProductsList;
    private ArrayList<ModelOrderUser> ordersList;

    private AdapterShoppingList adapterCartProducts;
    private AdapterProduct adapterProduct;
    private AdapterSupermarket adapterSupermarket;
    private AdapterOrderUser adapterOrderUser;

    private FusedLocationProviderClient fusedLocationProviderClient;

    //public ArrayList<ModelProduct> cartOfproducts = (ArrayList<ModelProduct>) getIntent().getSerializableExtra("CartOfProducts");

    Button showResultBtn;
    Button confirmBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        nameTv = findViewById(R.id.nameTv);
        emailTv = findViewById(R.id.emailTv);
        tabProductsTv = findViewById(R.id.tabProductsTv);
        tabShoppingListTv = findViewById(R.id.tabShoppingListTv);
        tabSupermarketTv = findViewById(R.id.tabSupermarketTv);
        tabHistoryTv = findViewById(R.id.tabHistoryTv);
        searchProductEt = findViewById(R.id.searchProductEt);
        logoutBtn = findViewById(R.id.logoutBtn);
        filterProductBtn = findViewById(R.id.filterProductBtn);
        productsRl = findViewById(R.id.productsRl);
        shoppingListRl = findViewById(R.id.shoppingListRl);
        supermarketRl = findViewById(R.id.supermarketRl);
        historyRl = findViewById(R.id.historyRl);
        filteredProductTv = findViewById(R.id.filteredProductTv);
        productsRv = findViewById(R.id.productsRv);
        supermarketRv = findViewById(R.id.supermarketRv);
        shoppingListtRv = findViewById(R.id.shoppingListtRv);
        historyRv = findViewById(R.id.historyRv);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);
        firebaseAuth = FirebaseAuth.getInstance();
        confirmBtn = findViewById(R.id.confirmBtn);
        showResultBtn = findViewById(R.id.showResultBtn);

        //check if there is a logged user
        checkUser();

        loadAllProducts();

        //at start show products ui
        showProductsUI();
        storeLocation();

        //search
        searchProductEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    adapterProduct.getFilter().filter(s);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add to db
                addToShoppingList(cartProductsList, view);

            }
        });


        showResultBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // get Location and store in database
                getUserLocation();
                //showResultMethod(cartProductsList, view);
            }
        });


        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //make offline
                //sign out
                //go to login activity
                makeMeOffline();
            }
        });


        tabProductsTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //load products
                showProductsUI();
            }
        });

        tabShoppingListTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //load shopping list
                showShoppingListUI();
                LoadCartProducts();

            }
        });

        tabHistoryTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //load history
                showHistoryUI();
                LoadOrders();
            }
        });

        tabSupermarketTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //load supermarkets
                showSupermarketUI();
                loadSupermarkets();

            }
        });

        filterProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainUserActivity.this);
                builder.setTitle("Choose Category:")
                        .setItems(Constants.productCategories1, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //get selected item
                                String selected = Constants.productCategories1[which];
                                filteredProductTv.setText(selected);
                                if (selected.equals("All")) {
                                    //load all
                                    loadAllProducts();
                                } else {
                                    //load filtered
                                    loadFilteredProducts(selected);
                                }
                            }
                        })
                        .show();
            }
        });
    }


    private void addToShoppingList(ArrayList<ModelProduct> cartt, View v) {
        double summ = 0.0;
        String orderAmount;
        for (int i = 0; i < cartt.size(); i++) {
            summ += cartt.get(i).getAveragePrice();
        }
        orderAmount = String.valueOf(summ);
        String timesTamp = "" + System.currentTimeMillis();
        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("orderId", timesTamp);
        cartMap.put("orderTime", timesTamp);
        cartMap.put("orderAmount", orderAmount + "$");
        cartMap.put("userId", FirebaseAuth.getInstance().getCurrentUser().getUid());
        cartMap.put("products", cartt);

        final DatabaseReference cartOfshoppinglist = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Order");

        cartOfshoppinglist
                .push()
                .setValue(
                        cartMap
                ).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(v.getContext(), "Shopping List is created" +
                        "", Toast.LENGTH_SHORT).show();
            }
        });
/*
                .child(timesTamp).setValue(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        String pid,name,quantity;
                        if(task.isSuccessful())
                        {
                            for(int i=0;i<cartt.size();i++)
                            {
                                pid = cartt.get(i).getProductId();
                                name = cartt.get(i).getProductName();
                                quantity = cartt.get(i).getProductquant();

                                final HashMap<String, String> cartMap2 = new HashMap<>();
                                cartMap2.put("pid", pid);
                                cartMap2.put("productName", "" + name);
                                cartMap2.put("productQuantity", "" + quantity);
                                cartOfshoppinglist.child(timesTamp).child("Products").child(pid).setValue(cartMap2);
                            }
                                Toast.makeText(v.getContext(), "Adeed to cart", Toast.LENGTH_SHORT).show();



                        }
                    }
                });
*/
        adapterProduct.getCartOfproducts().clear();
        final DatabaseReference cartref = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Cartt");
        cartref.removeValue();
        //final DatabaseReference reff= FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Order");
        //reff.removeValue();

    }

    private void storeLocation() {
        if (ActivityCompat.checkSelfPermission(MainUserActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // When permission granted
            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    // Initialize location
                    Location ulocation = task.getResult();
                    if (ulocation != null) {

                        Double lat = ulocation.getLatitude();
                        Double longt = ulocation.getLongitude();

                        sendLocation(ulocation);
                        //smDistances(ulocation);

                    } else {
                        //Location is null
                        requestNewLocation();
                    }
                }
            });

        } else {
            //When permission denied
            ActivityCompat.requestPermissions(MainUserActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);

        }
    }


    Location ulocation = new Location("Ulocation");

    private void getUserLocation() {
        final DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Location");

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Double ulatitude = snapshot.child("latitude").getValue(Double.class);
                Double ulongitude = snapshot.child("longitude").getValue(Double.class);

                ulocation.setLatitude(ulatitude);
                ulocation.setLongitude(ulongitude);

                getAllSms();

                // showResultMethod(cartProductsList, MainUserActivity.this, ulocation, null, null, null);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }


    private void showResultMethod(ArrayList<ModelProduct> cart, MainUserActivity v, Location ulocation, List<ModelSupermarket> Supermarkets) {
        double Total = 0.0;

        if (cart != null) {
            for (int i = 0; i < cart.size(); i++) {
                Total += cart.get(i).getAveragePrice();
            }
            //Toast.makeText(this, "Total of loop1 = " + Total, Toast.LENGTH_SHORT).show();

            storeLocation();

            //double userLat = getUserLocation().getLatitude();
            //Toast.makeText(this, "Latitude = " + userLat, Toast.LENGTH_SHORT).show();

            Double Ulat = ulocation.getLatitude();
            Double Ulongt = ulocation.getLongitude();


            //List <Double> finalTotals = new ArrayList<>();
            List<Double> supermarketsLocsCosts = new ArrayList<>();
            for (ModelSupermarket msm : Supermarkets) {
                Double latt = msm.getLatitude();
                Double longtt = msm.getLongitude();

                Location smLoc = new Location("SMLOC");
                smLoc.setLatitude(latt);
                smLoc.setLongitude(longtt);

                Double dist = findDistance(ulocation, smLoc);
                Double dcost = dist * 0.00028;
                supermarketsLocsCosts.add(dcost);
                //Toast.makeText(v, "Distance = " + dist, Toast.LENGTH_SHORT).show();
                //Toast.makeText(v, "Distance Cost = " + dcost, Toast.LENGTH_SHORT).show();
            }
        /*
        Double dcost1 = supermarketsLocs.get(0);
        Double dcost2 = supermarketsLocs.get(1);
        Double dcost3 = supermarketsLocs.get(2);
*/
            //Toast.makeText(v, "DCost1 = " + dcost1, Toast.LENGTH_SHORT).show();
            //Toast.makeText(this, "ULat = " + Ulat + " ULongt = " + Ulongt, Toast.LENGTH_SHORT).show();

            if (Total < 100) {
                Toast.makeText(this, "Total is < 100", Toast.LENGTH_SHORT).show();


                //for (ModelSupermarket sm : Supermarkets){
                //String supermarketId = sm.getSupermarketId();
                DatabaseReference smReference = FirebaseDatabase.getInstance().getReference("Supermarkets");
                //.child(supermarketId).child("products");
                smReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    List<Double> smTotals = new ArrayList<>();
                    Double TotalCost = 0.0;
                    int index = 0;

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //List<ModelsmProduct> smproducts= new ArrayList<>();
                        List<ModelSupermarket> allsupermarkets = new ArrayList<>();
                        for (DataSnapshot snap : snapshot.getChildren()) {

                            ModelSupermarket superm = snap.getValue(ModelSupermarket.class);
                            superm.setSupermarketId(snap.getKey());

                            TotalCost=0.0;
                            for (DataSnapshot pSnap : snap.child("products").getChildren()){
                                ModelsmProduct smp = pSnap.getValue(ModelsmProduct.class);
                                smp.setProductId(pSnap.getKey());
                                for (ModelProduct cartproduct : cart) {
                                    if (smp != null && cartproduct.getProductId().equals(smp.getProductId())) {
                                        int pAmount = new Integer(cartproduct.getProductquant());
                                        //smproducts.add(smProduct);
                                        TotalCost += pAmount * smp.getRealPrice();
                                    }
                                }//CartProduct
                            }
                            allsupermarkets.add(superm);

                            smTotals.add(TotalCost + supermarketsLocsCosts.get(index));
                            index += 1;
                        }//DataSnapshot (Supermarkets)

                        int minIndex = findLeastsmCost(smTotals);
                        ModelSupermarket leastsm = allsupermarkets.get(minIndex);
                        Intent smIntent = new Intent(MainUserActivity.this, SupermarketActivity.class);

                        smIntent.putExtra("supermarket", leastsm);
                        startActivity(smIntent);
                        //Toast.makeText(MainUserActivity.this, "Index = " + leastsm, Toast.LENGTH_SHORT).show();
                    }// onDataChange

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                //}
                //Toast.makeText(this, "smTotals1 = " +smTotals.get(0), Toast.LENGTH_SHORT).show();


                //Toast.makeText(this, "Total is < 100" , Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(this, "Total is > 100", Toast.LENGTH_SHORT).show();


                List<List<ModelProduct>> Res = new ArrayList<>();
                Res = kmeans(cartProductsList);

                List<ModelProduct> c1 = new ArrayList<>();
                List<ModelProduct> c2 = new ArrayList<>();
                List<ModelProduct> c3 = new ArrayList<>();

                c1 = Res.get(0);
                c2 = Res.get(1);
                c3 = Res.get(2);

                /*for (int i=0; i<c1.size(); i++){
                    Toast.makeText(v, "Cluster1 product: " + c1.get(i).getProductId(), Toast.LENGTH_SHORT).show();
                }

                for (int i=0; i<c2.size(); i++){
                    Toast.makeText(v, "Cluster2 product: " + c2.get(i).getProductId(), Toast.LENGTH_SHORT).show();
                }

                for (int i=0; i<c3.size(); i++){
                    Toast.makeText(v, "Cluster3 product: " + c3.get(i).getProductId(), Toast.LENGTH_SHORT).show();
                }*/


                DatabaseReference supermsRef = FirebaseDatabase.getInstance().getReference("Supermarkets");
                List<ModelProduct> finalC1 = c1;
                List<ModelProduct> finalC2 = c2;
                List<ModelProduct> finalC3 = c3;
                supermsRef.addListenerForSingleValueEvent(new ValueEventListener() {

                    List<Double> cluster1Sums = new ArrayList<>();
                    List<Double> cluster2Sums = new ArrayList<>();
                    List<Double> cluster3Sums = new ArrayList<>();
                    int index = 0;
                    Double Total1 = 0.0;
                    Double Total2 = 0.0;
                    Double Total3 = 0.0;

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        List<ModelSupermarket> allsupermarkets = new ArrayList<>();
                        for (DataSnapshot snap : snapshot.getChildren()) {

                            ModelSupermarket superm = snap.getValue(ModelSupermarket.class);// single supermarket
                            superm.setSupermarketId(snap.getKey());

                            Total1=0.0;
                            Total2=0.0;
                            Total3=0.0;
                            for (DataSnapshot pSnap : snap.child("products").getChildren()){ // Products of Supermarket
                                ModelsmProduct smp = pSnap.getValue(ModelsmProduct.class); // SupermarketProduct
                                smp.setProductId(pSnap.getKey());

                                for (ModelProduct cluster1Product : finalC1) {
                                    if (smp != null && cluster1Product.getProductId().equals(smp.getProductId())) {
                                        int pAmount = new Integer(cluster1Product.getProductquant());
                                        Total1 += pAmount * smp.getRealPrice();
                                    }
                                }//Cluster1


                                for (ModelProduct cluster2Product : finalC2) {
                                    if (smp != null && cluster2Product.getProductId().equals(smp.getProductId())) {
                                        int pAmount = new Integer(cluster2Product.getProductquant());
                                        Total2 += pAmount * smp.getRealPrice();
                                    }
                                }//Cluster2

                                for (ModelProduct cluster3Product : finalC3) {
                                    if (smp != null && cluster3Product.getProductId().equals(smp.getProductId())) {
                                        int pAmount = new Integer(cluster3Product.getProductquant());
                                        Total3 += pAmount * smp.getRealPrice();
                                    }
                                }//Cluster3

                            } // Products of Supermarket

                            allsupermarkets.add(superm);
                            cluster1Sums.add(Total1 + supermarketsLocsCosts.get(index));
                            cluster2Sums.add(Total2 + supermarketsLocsCosts.get(index));
                            cluster3Sums.add(Total3 + supermarketsLocsCosts.get(index));
                            index+=1;
                        }//DataSnapshot (Supermarkets)

                        //Toast.makeText(v, "Cluster1 sums: " + cluster1Sums.get(0) + " " + cluster1Sums.get(1) + " " + cluster1Sums.get(2), Toast.LENGTH_SHORT).show();
                        //Toast.makeText(v, "Cluster2 sums: " + cluster2Sums.get(0) + " " + cluster2Sums.get(1) + " " + cluster2Sums.get(2), Toast.LENGTH_SHORT).show();
                        //Toast.makeText(v, "Cluster3 sums: " + cluster3Sums.get(0) + " " + cluster3Sums.get(1) + " " + cluster3Sums.get(2), Toast.LENGTH_SHORT).show();

                        int minIndex1 = findLeastsmCost(cluster1Sums);
                        ModelSupermarket leastsm1 = allsupermarkets.get(minIndex1);

                        int minIndex2 = findLeastsmCost(cluster2Sums);
                        ModelSupermarket leastsm2 = allsupermarkets.get(minIndex2);

                        int minIndex3 = findLeastsmCost(cluster3Sums);
                        ModelSupermarket leastsm3 = allsupermarkets.get(minIndex3);

                        Toast.makeText(v, "Indexes are: " + leastsm1.getSupermarketId() + leastsm2.getSupermarketId()
                                + leastsm3.getSupermarketId(), Toast.LENGTH_SHORT).show();

                        ModelSupermarket Res1;
                        ModelSupermarket Res2;
                        ModelSupermarket Res3;

                        List<ModelProduct> Res1Products = new ArrayList<>();
                        List<ModelProduct> Res2Products = new ArrayList<>();
                        List<ModelProduct> Res3Products = new ArrayList<>();

                        List<ModelSupermarket> smRes = new ArrayList<>();
                        List<List<ModelProduct>> smProd = new ArrayList<>();

                        if (minIndex1 == minIndex2 && minIndex1 == minIndex3){
                            Res1 = leastsm1;
                            Res1Products = finalC1;
                            Res1Products.addAll(finalC2);
                            Res1Products.addAll(finalC3);
                            smRes.add(Res1);
                            Intent smIntent = new Intent(MainUserActivity.this, SupermarketsClusteringResult.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("Supermarkets", (Serializable) smRes);
                            bundle.putSerializable("Products1", (Serializable) Res1Products);
                            smIntent.putExtra("Bundle", bundle);
                            startActivity(smIntent);


                            Toast.makeText(v, "Result = " + leastsm1.getSupermarketId(), Toast.LENGTH_SHORT).show();
                        } else if (minIndex1 == minIndex2 && minIndex1 != minIndex3){
                            Res1 = leastsm1;
                            Res1Products = finalC1;
                            Res1Products.addAll(finalC2);

                            Res2 = leastsm3;
                            Res2Products = finalC3;

                            smRes.add(Res1);
                            smRes.add(Res2);
                            Intent smIntent = new Intent(MainUserActivity.this, SupermarketsClusteringResult.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("Supermarkets", (Serializable) smRes);
                            bundle.putSerializable("Products1", (Serializable) Res1Products);
                            bundle.putSerializable("Products2", (Serializable) Res2Products);
                            smIntent.putExtra("Bundle", bundle);
                            startActivity(smIntent);
                            Toast.makeText(v, "Result1 = " + Res1.getSupermarketId() + " , Result2 = " + Res2.getSupermarketId()
                                    , Toast.LENGTH_SHORT).show();

                        } else if (minIndex1 == minIndex3 && minIndex1 != minIndex2){
                            Res1 = leastsm1;
                            Res1Products = finalC1;
                            Res1Products.addAll(finalC3);
                            Res2 = leastsm2;
                            Res2Products = finalC2;
                            smRes.add(Res1);
                            smRes.add(Res2);
                            Intent smIntent = new Intent(MainUserActivity.this, SupermarketsClusteringResult.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("Supermarkets", (Serializable) smRes);
                            bundle.putSerializable("Products1", (Serializable) Res1Products);
                            bundle.putSerializable("Products2", (Serializable) Res2Products);
                            smIntent.putExtra("Bundle", bundle);
                            startActivity(smIntent);
                            Toast.makeText(v, "Result1 = " + Res1.getSupermarketId() + " , Result2 = " + Res2.getSupermarketId(),
                                    Toast.LENGTH_SHORT).show();
                        } else if (minIndex2 == minIndex3 && minIndex2 != minIndex1){
                            Res1 = leastsm2;
                            Res1Products = finalC2;
                            Res1Products.addAll(finalC3);
                            Res2 = leastsm1;
                            Res2Products = finalC1;
                            smRes.add(Res1);
                            smRes.add(Res2);
                            Intent smIntent = new Intent(MainUserActivity.this, SupermarketsClusteringResult.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("Supermarkets", (Serializable) smRes);
                            bundle.putSerializable("Products1", (Serializable) Res1Products);
                            bundle.putSerializable("Products2", (Serializable) Res2Products);
                            smIntent.putExtra("Bundle", bundle);
                            startActivity(smIntent);
                            Toast.makeText(v, "Result1 = " + Res1.getSupermarketId() + " , Result2 = " + Res2.getSupermarketId()
                                    , Toast.LENGTH_SHORT).show();
                        } else {
                            Res1 = leastsm1;
                            Res1Products = finalC1;
                            Res2 = leastsm2;
                            Res2Products = finalC2;
                            Res3 = leastsm3;
                            Res3Products = finalC3;
                            smRes.add(Res1);
                            smRes.add(Res2);
                            smRes.add(Res3);
                            Intent smIntent = new Intent(MainUserActivity.this, SupermarketsClusteringResult.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("Supermarkets", (Serializable) smRes);
                            bundle.putSerializable("Products1", (Serializable) Res1Products);
                            bundle.putSerializable("Products2", (Serializable) Res2Products);
                            bundle.putSerializable("Products3", (Serializable) Res3Products);
                            smIntent.putExtra("Bundle", bundle);
                            startActivity(smIntent);
                            Toast.makeText(v, "Result1 = " + Res1.getSupermarketId() + " , Result2 = " + Res2.getSupermarketId()
                                    + ", Result3 = " + Res3.getSupermarketId(), Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        }
    }

    private void getAllSms() {

        DatabaseReference smReference = FirebaseDatabase.getInstance().getReference("Supermarkets");
        smReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ModelSupermarket> smList = new ArrayList<>();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    ModelSupermarket SM = snap.getValue(ModelSupermarket.class);
                    SM.setSupermarketId(snap.getKey());
                    smList.add(SM);
                }
                showResultMethod(cartProductsList, MainUserActivity.this, ulocation, smList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private List<List<ModelProduct>> kmeans(ArrayList<ModelProduct> cartProductsList){
        int i, m1, m2,m3, n = 0;
        boolean flag;
        Double sum1, sum2, sum3;

        int a = (int)cartProductsList.get(0).getAveragePrice();
        int b = (int)cartProductsList.get(1).getAveragePrice();
        int c = (int)cartProductsList.get(2).getAveragePrice();

        m1 = (int) Math.round(a);
        m2 = (int) Math.round(b);
        m3 = (int) Math.round(c);

        List <ModelProduct> cluster1 = new ArrayList<>();
        List <ModelProduct> cluster2 = new ArrayList<>();
        List <ModelProduct> cluster3 = new ArrayList<>();

        do {
            cluster1.clear();
            cluster2.clear();
            cluster3.clear();

            sum1 = 0.0;
            sum2 = 0.0;
            sum3 = 0.0;

           n++;
           int k=0, j=0, r=0;

           for (i = 0; i<cartProductsList.size(); i++){
               if (Math.abs(cartProductsList.get(i).getAveragePrice() - m1) <= Math.abs(cartProductsList.get(i).getAveragePrice() - m2)
               && Math.abs(cartProductsList.get(i).getAveragePrice() - m1) <= Math.abs(cartProductsList.get(i).getAveragePrice() - m3)
               ){
                   cluster1.add(cartProductsList.get(i));
                  // k++;
               } else if (Math.abs(cartProductsList.get(i).getAveragePrice() - m2) <= Math.abs(cartProductsList.get(i).getAveragePrice() - m1)
                       && Math.abs(cartProductsList.get(i).getAveragePrice() - m2) <= Math.abs(cartProductsList.get(i).getAveragePrice() - m3)
               ){
                    cluster2.add(cartProductsList.get(i));
                   // j++;
               } else {
                   cluster3.add(cartProductsList.get(i));
                   //r++;
               }
           }

           for (i=0; i<cluster1.size(); i++){
               sum1 = sum1 + cluster1.get(i).getAveragePrice();
           }

            for (i=0; i<cluster2.size(); i++){
                sum2 = sum2 + cluster2.get(i).getAveragePrice();
            }

            for (i=0; i<cluster3.size(); i++){
                sum3 = sum3 + cluster3.get(i).getAveragePrice();
            }

            a = m1;
            b = m2;
            c = m3;

            m1 = (int) Math.round(sum1/cluster1.size());
            m2 = (int) Math.round(sum2/cluster2.size());
            m3 = (int) Math.round(sum3/cluster3.size());
            flag = !(m1 == a && m2 == b && m3 == c);

        //}while (flag);
        }while (flag);

        List<List<ModelProduct>> Result = new ArrayList<>();
        Result.add(cluster1);
        Result.add(cluster2);
        Result.add(cluster3);

        return Result;
    }

    // ArrayList <Double> Totals = new ArrayList<>();
    /*private void getsmProducts(ModelSupermarket supermarket) {

        String supermarketId = supermarket.getSupermarketId();
        DatabaseReference smReference = FirebaseDatabase.getInstance().getReference("Supermarkets")
                .child(supermarketId).child("products");
        smReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ModelsmProduct> smproducts = new ArrayList<>();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    ModelsmProduct smProduct = snap.getValue(ModelsmProduct.class);
                    smproducts.add(smProduct);
                    // for (ModelProduct product : CartProducts){
                    // if (smProduct.getProductId() == product.getProductId()){
                    // Totals.add(smProduct.getRealPrice());
                    // }
                    // }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }*/


    private Double findDistance(Location startPoint, Location endPoint) {


        double distance = startPoint.distanceTo(endPoint);
        return distance;
    }

    private void sendLocation(Location location) {
        final DatabaseReference userLoc = FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Location");

        userLoc.setValue(location).addOnCompleteListener(Loctask -> {
            if (Loctask.isSuccessful()) {
                Toast.makeText(MainUserActivity.this, "Location is stored!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int findLeastsmCost(List<Double> Totals) {
        int index = 0;
        Double LeastTotal = Totals.get(0);
        for (int i = 1; i < Totals.size(); i++) {

            if (Totals.get(i) < LeastTotal) {
                LeastTotal = Totals.get(i);
                index = i;
            }
        }

        return index;
    }


    private void requestNewLocation() {
        LocationRequest locationRequest = new LocationRequest();

        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest);


        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        // Request Location if location settings are enabled.
        task.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                // All location settings are satisfied.
                if (ActivityCompat.checkSelfPermission(
                        MainUserActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                        || ActivityCompat.checkSelfPermission(
                        MainUserActivity.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                ) {
                    fusedLocationProviderClient.requestLocationUpdates(
                            locationRequest,
                            locationCallback,
                            Looper.getMainLooper());

                }
            }
        });

        task.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        ((ResolvableApiException) e).startResolutionForResult(
                                MainUserActivity.this,
                                REQUEST_CODE_CHECK_SETTINGS
                        );
                    } catch (IntentSender.SendIntentException sendIntentException) {
                        // Ignore the error.
                    }
                }
            }
        });
    }

    int REQUEST_CODE_CHECK_SETTINGS = 1;
    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            super.onLocationResult(locationResult);
            sendLocation(locationResult.getLastLocation());
            fusedLocationProviderClient.removeLocationUpdates(this);

        }
    };

    public void LoadCartProducts() {
        cartProductsList = new ArrayList<>();
        //get all cartProducts
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Cartt");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //before getting reset list
                cartProductsList.clear();
                for (DataSnapshot ds2 : dataSnapshot.getChildren()) {
                    ModelProduct modelCartProduct = ds2.getValue(ModelProduct.class);
                    cartProductsList.add(modelCartProduct);
                }

                //setup adapter
                adapterCartProducts = new AdapterShoppingList(MainUserActivity.this, cartProductsList);
                adapterCartProducts.setListener(new AdapterCallback() {
                    @Override
                    public void onProductRemoved(ModelProduct product) {
                        cartProductsList.remove(product);
                        adapterProduct.getCartOfproducts().remove(product);
                        FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getUid())
                                .child("Cartt").child(product.getProductId())
                                .removeValue();
                        adapterCartProducts.notifyDataSetChanged();
                        adapterProduct.notifyDataSetChanged();
                    }
                });
                //set adapter
                shoppingListtRv.setAdapter(adapterCartProducts);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void loadSupermarkets() {
        supermarketList = new ArrayList<>();


        //get all supermarkets
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Supermarkets");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //before getting reset list
                supermarketList.clear();
                for (DataSnapshot ds1 : dataSnapshot.getChildren()) {
                    ModelSupermarket modelSupermarket = ds1.getValue(ModelSupermarket.class);
                    modelSupermarket.setSupermarketId(ds1.getKey());
                    supermarketList.add(modelSupermarket);
                }

                //setup adapter
                adapterSupermarket = new AdapterSupermarket(MainUserActivity.this, supermarketList);
                //set adapter
                supermarketRv.setAdapter(adapterSupermarket);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void loadFilteredProducts(String selected) {
        productList = new ArrayList<>();

        //get all products
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Products");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //before getting reset list
                productList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    String productCategory = "" + ds.child("productCategory").getValue();

                    //if selected category matches product category then add in list
                    if (selected.equals(productCategory)) {
                        ModelProduct modelProduct = ds.getValue(ModelProduct.class);
                        productList.add(modelProduct);
                    }
                }

                //setup adapter
                adapterProduct = new AdapterProduct(MainUserActivity.this, productList, true);
                //set adapter
                productsRv.setAdapter(adapterProduct);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void loadAllProducts() {

        productList = new ArrayList<>();
//FirebaseAuth.getInstance().getCurrentUser().getUid()

        //get all products
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Products");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //before getting reset list
                productList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    ModelProduct modelProduct = ds.getValue(ModelProduct.class);
                    modelProduct.setProductId(ds.getKey());
                    productList.add(modelProduct);
                }

                //setup adapter
                adapterProduct = new AdapterProduct(MainUserActivity.this, productList, true);
                //set adapter
                productsRv.setAdapter(adapterProduct);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void showProductsUI() {
        //show products ui and hide shopping list ui and hide history ui
        productsRl.setVisibility(View.VISIBLE);
        shoppingListRl.setVisibility(View.GONE);
        historyRl.setVisibility(View.GONE);
        supermarketRl.setVisibility(View.GONE);

        tabProductsTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabProductsTv.setBackgroundResource(R.drawable.shape_rect04);

        tabShoppingListTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabShoppingListTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabHistoryTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabHistoryTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabSupermarketTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabSupermarketTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    public void showShoppingListUI() {
        //show shopping list ui and hide products ui and hide history ui
        productsRl.setVisibility(View.GONE);
        historyRl.setVisibility(View.GONE);
        shoppingListRl.setVisibility(View.VISIBLE);
        supermarketRl.setVisibility(View.GONE);

        tabShoppingListTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabShoppingListTv.setBackgroundResource(R.drawable.shape_rect04);

        tabProductsTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabProductsTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabHistoryTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabHistoryTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabSupermarketTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabSupermarketTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void showSupermarketUI() {
        productsRl.setVisibility(View.GONE);
        historyRl.setVisibility(View.GONE);
        shoppingListRl.setVisibility(View.GONE);
        supermarketRl.setVisibility(View.VISIBLE);

        tabSupermarketTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabSupermarketTv.setBackgroundResource(R.drawable.shape_rect04);

        tabProductsTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabProductsTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabHistoryTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabHistoryTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabShoppingListTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabShoppingListTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void showHistoryUI() {
        //show history ui and hide products ui and hide shopping list ui
        productsRl.setVisibility(View.GONE);
        historyRl.setVisibility(View.VISIBLE);
        shoppingListRl.setVisibility(View.GONE);
        supermarketRl.setVisibility(View.GONE);

        tabHistoryTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabHistoryTv.setBackgroundResource(R.drawable.shape_rect04);

        tabProductsTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabProductsTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabShoppingListTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabShoppingListTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabSupermarketTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabSupermarketTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void makeMeOffline() {
        //after logging in , make user online
        progressDialog.setMessage("Logging out ...");
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("online", "false");

        //update value to db
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).updateChildren(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        //update, successfully
                        firebaseAuth.signOut();
                        checkUser();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //failed updating
                        progressDialog.dismiss();
                        Toast.makeText(MainUserActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void checkUser() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user == null) {
            startActivity(new Intent(MainUserActivity.this, LoginActivity.class));
            finish();
        } else {
            loadMyInfo();
        }
    }

    private void loadMyInfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            //get user data
                            String name = "" + ds.child("name").getValue();
                            String email = "" + ds.child("email").getValue();

                            //set user data
                            nameTv.setText(name);
                            emailTv.setText(email);


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void LoadOrders() {

        ordersList = new ArrayList<>();
        adapterOrderUser = new AdapterOrderUser(MainUserActivity.this, ordersList);
        historyRv.setAdapter(adapterOrderUser);
        FirebaseDatabase.getInstance().getReference().child("Users")
                .child(firebaseAuth.getUid()).child("Order").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()) {
                    ModelOrderUser modelOrderUser = ds.getValue(ModelOrderUser.class);
                    ordersList.add(modelOrderUser);

                }

                adapterOrderUser.submitList(ordersList);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}