package com.example.groceryapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterProduct;
import com.example.groceryapp.adapters.AdapterSmRes;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.models.ModelSupermarket;

import java.util.ArrayList;

public class ProductsOfCluster extends AppCompatActivity {


    private AdapterProduct AdapterProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products_of_cluster);

        RecyclerView smResView = findViewById(R.id.smResView);

        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("Bundle");
        ArrayList<ModelProduct> productsRes = (ArrayList<ModelProduct>) args.getSerializable("Products");

        AdapterProduct = new AdapterProduct(this, productsRes, false);
        //set adapter
        smResView.setAdapter(AdapterProduct);
        smResView.setLayoutManager(new LinearLayoutManager(this));
    }
}