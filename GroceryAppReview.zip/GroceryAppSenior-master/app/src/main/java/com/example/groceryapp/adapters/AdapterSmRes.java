package com.example.groceryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.models.*;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterSmRes extends RecyclerView.Adapter<AdapterSmRes.HolderSupermarket>{

    private Context context;
    public ArrayList<ModelSupermarket> supermarketList;
    private SmResListener listener;

    public AdapterSmRes(Context context, ArrayList<ModelSupermarket> supermarketList, SmResListener listener) {
        this.context = context;
        this.supermarketList = supermarketList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HolderSupermarket onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout
        View view = LayoutInflater.from(context).inflate(R.layout.sm_single_res,parent,false);
        return new HolderSupermarket(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderSupermarket holder, int position) {

        //get data
        ModelSupermarket modelSupermarket = supermarketList.get(position);
        String id = modelSupermarket.getSupermarketId();
        String supermarketAddress = modelSupermarket.getAddress();
        String icon = modelSupermarket.getSupermarketImage();
        String name = modelSupermarket.getSupermarketName();

        ///set data
        holder.supermarketNameTv.setText(name);
        holder.supermarketAddressTv.setText(supermarketAddress);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClicked(holder.getAdapterPosition(), supermarketList.get(holder.getAdapterPosition()));
            }
        });

        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_store).into(holder.supermarketIconIv);
        }
        catch (Exception e){
            holder.supermarketIconIv.setImageResource(R.drawable.ic_store);
        }

    }

    @Override
    public int getItemCount() {
        return supermarketList.size();
    }

    //view holder
    class HolderSupermarket extends RecyclerView.ViewHolder{

        private ImageView supermarketIconIv;
        private TextView supermarketNameTv, supermarketAddressTv;

        public HolderSupermarket(@NonNull View itemView) {
            super(itemView);

            supermarketIconIv = itemView.findViewById(R.id.supermarketIconIv);
            supermarketNameTv = itemView.findViewById(R.id.supermarketNameTv);
            supermarketAddressTv = itemView.findViewById(R.id.supermarketAddressTv);
        }
    }

    public interface SmResListener{
        void onItemClicked(int index, ModelSupermarket item);
    }
}
