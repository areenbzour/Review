package com.example.groceryapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Adapter;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterSmRes;
import com.example.groceryapp.adapters.AdapterSupermarket;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.models.ModelSupermarket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SupermarketsClusteringResult extends AppCompatActivity implements AdapterSmRes.SmResListener {

    //private Adapter adapterSupermarket;
    private AdapterSmRes adapterSupermarket;

    List<ModelProduct> products1;
    List<ModelProduct> products2;
    List<ModelProduct> products3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supermarkets_clustering_result);

        RecyclerView smResView = findViewById(R.id.smResView);

        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("Bundle");
        ArrayList<ModelSupermarket> smRes = (ArrayList<ModelSupermarket>) args.getSerializable("Supermarkets");

        adapterSupermarket = new AdapterSmRes(SupermarketsClusteringResult.this, smRes, this);
        //set adapter
        smResView.setAdapter(adapterSupermarket);
        smResView.setLayoutManager(new LinearLayoutManager(this));

        if (args.getSerializable("Products1") != null){
            products1 = (List<ModelProduct>) args.getSerializable("Products1");
        }
        if (args.getSerializable("Products2") != null){
            products2 = (List<ModelProduct>) args.getSerializable("Products2");
        }
        if (args.getSerializable("Products3") != null){
            products3 = (List<ModelProduct>) args.getSerializable("Products3");
        }



    }

    @Override
    public void onItemClicked(int index, ModelSupermarket item) {
        // open acctitiy,
        if (index == 0){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products1);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
        if (index ==1){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products2);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
        if (index ==2){
            Intent intent = new Intent(SupermarketsClusteringResult.this,ProductsOfCluster.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("Products", (Serializable) products3);
            intent.putExtra("Bundle", bundle);
            startActivity(intent);
        }
    }
}