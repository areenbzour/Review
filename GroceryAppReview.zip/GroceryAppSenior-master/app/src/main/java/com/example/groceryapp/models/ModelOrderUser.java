package com.example.groceryapp.models;

import java.util.ArrayList;

public class ModelOrderUser {
   String orderId;
    String orderTime;
    String userId;
    String orderAmount;
    ArrayList<ModelProduct> products=new ArrayList<>();

    public ModelOrderUser() {

    }

    public ModelOrderUser(String orderId, String orderTime, String userId, ArrayList<ModelProduct> productss) {
        this.orderId = orderId;
        this.orderTime = orderTime;
        this.userId = userId;
        for(int i=0;i<productss.size();i++)
        {
             products.add(productss.get(i));
        }

    }

    public ModelOrderUser(String orderId, String orderTime, String userId) {
        this.orderId = orderId;
        this.orderTime = orderTime;
        this.userId = userId;
    }
    public String getOrderAmount() {
        return orderAmount;
    }


    public String getOrderId() {
        return orderId;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public String getUserId() {
        return userId;
    }
    public ArrayList<ModelProduct> getProducts()
    {
        return products;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setProducts(ArrayList<ModelProduct> productss) {
        for(int i=0;i<productss.size();i++)
        {
            products.add(productss.get(i));
        }
    }

}
