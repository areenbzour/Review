package com.example.groceryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.Constants;
import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelOrderUser;
import com.example.groceryapp.models.ModelProduct;

import java.text.DateFormat;
import java.text.DateFormat.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdapterOrderUser extends RecyclerView.Adapter<AdapterOrderUser.HolderOrderUser> {
    private Context context;
    private List<ModelOrderUser> orderUserList;

    public void submitList(List<ModelOrderUser> list){
        orderUserList = list;
        notifyDataSetChanged();
    }

    public AdapterOrderUser(Context context, ArrayList<ModelOrderUser> orderUserList) {
        this.context = context;
        this.orderUserList = orderUserList;
    }

    @NonNull
    @Override
    public HolderOrderUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.show_history,parent,false);
        return new AdapterOrderUser.HolderOrderUser(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderOrderUser holder, int position) {
        //get data
        ModelOrderUser modelOrderUser=orderUserList.get(position);
        String orderId=modelOrderUser.getOrderId();
        String orderTime=modelOrderUser.getOrderTime();
        String userId=modelOrderUser.getUserId();
        String orderAmount=modelOrderUser.getOrderAmount();
        //set data
        holder.ordetTV.setText("Order Id=" +orderId);
        holder.amountTV.setText("Order Price=" +orderAmount);
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
      if (orderTime != null){
          String formattedDate=df.format( new Date(Long.parseLong(orderTime)));
          holder.dateTV.setText(formattedDate);
      }
      for (ModelProduct p : modelOrderUser.getProducts()){
          holder.productsTv.setText(holder.productsTv.getText() + p.getProductName() + "     X     "+ p.getProductquant() + "\n");
      }


    }


    @Override
    public int getItemCount() {
        return orderUserList.size();
    }

    //view holder class
    class HolderOrderUser extends RecyclerView.ViewHolder {
        //view of layout
        private TextView ordetTV,dateTV,amountTV,productsTv;

        public HolderOrderUser(@NonNull View itemView) {
            super(itemView);
            ordetTV=itemView.findViewById(R.id.ordetTV);
            dateTV=itemView.findViewById(R.id.dateTV);
            amountTV=itemView.findViewById(R.id.amountTV);
productsTv = itemView.findViewById(R.id.pname);
        }
    }
}
